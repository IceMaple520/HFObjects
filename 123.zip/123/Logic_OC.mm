#import "Logic_OC.h"
#import "../../../Logic/Logic.h"
#import "Tools/BasicTool/basic_tool.h"

@interface Logic_OC()

@property (nonatomic,assign) id<LogicListener> logicLisnter;
@property (nonatomic,assign) id<LogicRealPlayListener> logicRealPlayListener;
@property (nonatomic,assign) id<LogicSearchListener> logicSearchListener;
@property (nonatomic,assign) id<LogicTalkListener> logicTalkListener;
@property (nonatomic,assign) id<LogicMultiPreviewListener> logicMultiPreviewListener;
@property (nonatomic,assign) id<LogicPlayBackListener> logicPlayBackListener;

@end

bt::rwmutex g_lsnerMtx;

class oc_logic_listener : public logic_listener
{
public:
    virtual void on_server_state_change(const SERVER_STATE* state)
    {
        bt::auto_lock<bt::rwmutex::read_mutex> l(g_lsnerMtx.get_read_mutex());
        
        id<LogicListener> lsner = [[Logic_OC instance] logicLisnter];
        if (lsner)
        {
            [lsner onServerStateChange:state];
        }
    }
    virtual void on_device_state_change(int did, const DEVICE_STATE* state)
    {
        bt::auto_lock<bt::rwmutex::read_mutex> l(g_lsnerMtx.get_read_mutex());
        
        id<LogicListener> lsner = [[Logic_OC instance] logicLisnter];
        if (lsner)
        {
            [lsner onDeviceStateChange:did state:state];
        }
        
    }
}g_lsner;

class oc_logic_realplay_listener : public logic_realplay_listener
{
public:
    virtual void on_realplay_state_change(int did, int channel, int stream_type, const REALPLAY_STATE* state)
    {
        bt::auto_lock<bt::rwmutex::read_mutex> l(g_lsnerMtx.get_read_mutex());
        
        id<LogicRealPlayListener> lsner = [[Logic_OC instance] logicRealPlayListener];
        if (lsner)
        {
            [lsner onRealPlayStateChange:did channel:channel streamType:stream_type state:state];
        }
    }
    virtual void on_realplay_video(int did, int channel, int stream_type, VFRAME_INFO* vframe, const void* data, unsigned int len)
    {
        bt::auto_lock<bt::rwmutex::read_mutex> l(g_lsnerMtx.get_read_mutex());
        
        id<LogicRealPlayListener> lsner = [[Logic_OC instance] logicRealPlayListener];
        if (lsner)
        {
            [lsner onRealPlayVideo:did channel:channel steamType:stream_type vframe:vframe deta:data length:len];
        }
    }
    virtual void on_realplay_decoder_yuv(int did, int channel, int stream_type, VFRAME_INFO* vframe, const void* y, const void* u, const void* v)
    {
        bt::auto_lock<bt::rwmutex::read_mutex> l(g_lsnerMtx.get_read_mutex());
        
        id<LogicRealPlayListener> lsner = [[Logic_OC instance] logicRealPlayListener];
        if (lsner)
        {
            [lsner onRealPlayDecoderYUV:did channel:channel streamType:stream_type vframe:vframe y:y u:u v:v];
        }
    }
    virtual void on_realplay_audio(int did, int channel, int stream_type, AFRAME_INFO* aframe, const void* data, unsigned int len)
    {
        bt::auto_lock<bt::rwmutex::read_mutex> l(g_lsnerMtx.get_read_mutex());
        
        id<LogicRealPlayListener> lsner = [[Logic_OC instance] logicRealPlayListener];
        if (lsner)
        {
            [lsner onRealPlayAudio:did channel:channel streamType:stream_type aframe:aframe data:data length:len];
        }
    }
}g_realplay_lsner;

class oc_logic_search_listener : public logic_search_listener
{
public:
    virtual void on_search_device(const char* ip, int port)
    {
        bt::auto_lock<bt::rwmutex::read_mutex> l(g_lsnerMtx.get_read_mutex());
        
        id<LogicSearchListener> lsner = [[Logic_OC instance] logicSearchListener];
        if (lsner)
        {
            [lsner onSearchDevice:ip port:port];
        }
    }
}g_search_lsner;

class oc_logic_talk_listener : public logic_talk_listener
{
public:
    virtual void on_talk_result(int did, int error)
    {
        bt::auto_lock<bt::rwmutex::read_mutex> l(g_lsnerMtx.get_read_mutex());
        
        id<LogicTalkListener> lsner = [[Logic_OC instance] logicTalkListener];
        if (lsner)
        {
            [lsner onTalkResult:did error:error];
        }
    }
    virtual void on_talk_audio(int did, AFRAME_INFO* aframe, const void* data, unsigned int len)
    {
        bt::auto_lock<bt::rwmutex::read_mutex> l(g_lsnerMtx.get_read_mutex());
        
        id<LogicTalkListener> lsner = [[Logic_OC instance] logicTalkListener];
        if (lsner)
        {
            [lsner onTalkAudio:did aframe:aframe data:data length:len];
        }
    }
}g_talk_lsner;

class oc_logic_multi_preview_listener : public logic_multi_preview_listener
{
public:
    virtual void on_multi_preview_video(int did, VFRAME_INFO* vframe, const void* data, unsigned int len)
    {
        bt::auto_lock<bt::rwmutex::read_mutex> l(g_lsnerMtx.get_read_mutex());
        
        id<LogicMultiPreviewListener> lsner = [[Logic_OC instance] logicMultiPreviewListener];
        if (lsner)
        {
            [lsner onMultiPreviewVideo:did vframe:vframe data:data length:len];
        }
    }
    virtual void on_multi_preview_decoder_yuv(int did, VFRAME_INFO* vframe, const void* y, const void* u, const void* v)
    {
        bt::auto_lock<bt::rwmutex::read_mutex> l(g_lsnerMtx.get_read_mutex());
        
        id<LogicMultiPreviewListener> lsner = [[Logic_OC instance] logicMultiPreviewListener];
        if (lsner)
        {
            [lsner onMultiPreviewDecoderYUV:did vframe:vframe y:y u:u v:v];
        }
    }
}g_multi_preview_lsner;

class oc_logic_playback_listener : public logic_playback_listener
{
public:
    virtual void on_query_record(int did, int channel, int stream_type, LOGIC_RECORD_INFO* records, int num, int qr_param)
    {
        bt::auto_lock<bt::rwmutex::read_mutex> l(g_lsnerMtx.get_read_mutex());
        
        id<LogicPlayBackListener> lsner = [[Logic_OC instance] logicPlayBackListener];
        if (lsner)
        {
            [lsner onQueryRecord:did channel:channel streamType:stream_type records:records num:num qrParam:qr_param];
        }
    }
    virtual void on_playback_video(int did, int channel, int stream_type, LOGIC_TIME* time, VFRAME_INFO* vframe, const void* data, unsigned int len)
    {
        bt::auto_lock<bt::rwmutex::read_mutex> l(g_lsnerMtx.get_read_mutex());
        
        id<LogicPlayBackListener> lsner = [[Logic_OC instance] logicPlayBackListener];
        if (lsner)
        {
            [lsner onPlaybackVideo:did channel:channel streamType:stream_type time:time vframe:vframe data:data length:len];
        }
    }
    virtual void on_playback_decoder_yuv(int did, int channel, int stream_type, LOGIC_TIME* time, VFRAME_INFO* vframe, const void* y, const void* u, const void* v)
    {
        bt::auto_lock<bt::rwmutex::read_mutex> l(g_lsnerMtx.get_read_mutex());
        
        id<LogicPlayBackListener> lsner = [[Logic_OC instance] logicPlayBackListener];
        if (lsner)
        {
            [lsner onPlaybackDecoderYuv:did channel:channel streamType:stream_type time:time vframe:vframe y:y u:u v:v];
        }
    }
    virtual void on_playback_audio(int did, int channel, int stream_type, LOGIC_TIME* time, AFRAME_INFO* aframe, const void* data, unsigned int len)
    {
        bt::auto_lock<bt::rwmutex::read_mutex> l(g_lsnerMtx.get_read_mutex());
        
        id<LogicPlayBackListener> lsner = [[Logic_OC instance] logicPlayBackListener];
        if (lsner)
        {
            [lsner onPlaybackAudio:did channel:channel streamType:stream_type time:time aframe:aframe data:data length:len];
        }
    }

}g_playback_lsner;

extern "C"
{
    int Print(const char *libName, const char *file, int line, int nLevel, const char *fmt, ...)
    {
        char buf[1024];
        
        va_list ap;
        va_start(ap, fmt);
        bt::btstring_vsnprintf(buf, sizeof(buf), fmt, ap);
        va_end(ap);
        
        NSLog(@"[level=%d file=%s line=%d]:%s", nLevel, file, line, buf);
        return 0;
    }
}



static Logic_OC* g_logic_oc = nil;

@implementation Logic_OC

-(void) setLogicListener:(id<LogicListener>) lsner
{
    bt::auto_lock<bt::rwmutex::write_mutex> l(g_lsnerMtx.get_write_mutex());
    _logicLisnter = lsner;
}

-(void)setLogicRealPlayListener:(id<LogicRealPlayListener>)lsner
{
    bt::auto_lock<bt::rwmutex::write_mutex> l(g_lsnerMtx.get_write_mutex());
    _logicRealPlayListener = lsner;
}

-(void)setLogicSearchListener:(id<LogicSearchListener>)lsner
{
    bt::auto_lock<bt::rwmutex::write_mutex> l(g_lsnerMtx.get_write_mutex());
    _logicSearchListener = lsner;
}


-(void)setLogicTalkListener:(id<LogicTalkListener>)lsner
{
    bt::auto_lock<bt::rwmutex::write_mutex> l(g_lsnerMtx.get_write_mutex());
    _logicTalkListener = lsner;
}

-(void)setLogicMultiPreviewListener:(id<LogicMultiPreviewListener>)lsner
{
    bt::auto_lock<bt::rwmutex::write_mutex> l(g_lsnerMtx.get_write_mutex());
    _logicMultiPreviewListener = lsner;
}

-(void)setLogicPlayBackListener:(id<LogicPlayBackListener>)lsner
{
    bt::auto_lock<bt::rwmutex::write_mutex> l(g_lsnerMtx.get_write_mutex());
    _logicPlayBackListener = lsner;
}

+(Logic_OC *) instance
{
    @synchronized(self)
    {
        if (g_logic_oc == nil)
        {
            g_logic_oc = [[self alloc] init];
        }
    }
    
    return g_logic_oc;
}

-(void) init:(LOGIC_INIT_PARAM*)param
{
    g_logic.set_logic_listener(&g_lsner);
    g_logic.set_realplay_listener(&g_realplay_lsner);
    g_logic.set_search_listener(&g_search_lsner);
    g_logic.set_talk_listener(&g_talk_lsner);
    g_logic.set_multi_preview_listener(&g_multi_preview_lsner);
    g_logic.set_playback_listener(&g_playback_lsner);
    g_logic.init(param);
}

-(void)getServerState:(SERVER_STATE *)state
{
    g_logic.get_server_state(state);
}

-(long) getTick
{
    return (long)g_logic.get_tick();
}

-(void)refresh:(BOOL)force
{
    g_logic.refresh(force);
}

-(int) loginDevice:(DEVICE_LOGIN_PARAM *)param
{
    return g_logic.login_device(param);
}

-(void)logoutDevice:(int)did
{
    g_logic.logout_device(did);
}

-(void)getDeviceState:(int)did deviceState:(DEVICE_STATE *)state
{
    g_logic.get_device_state(did, state);
}

-(void)checkDevice:(DEVICE_LOGIN_PARAM *)param deviceState:(DEVICE_STATE *)state timeout:(unsigned int)timeout
{
    g_logic.check_device(param, state, timeout);
}

-(int)startRealPlay:(int)did channel:(int)channel streamType:(int)streamType decoder:(BOOL)decoder
{
    return g_logic.start_realplay(did, channel, streamType, decoder);
}

-(void)stopRealPlay:(int)did channel:(int)channel streamType:(int)streamType
{
    g_logic.stop_realplay(did, channel, streamType);
}

-(void)getRealPlayState:(int)did channel:(int)channel streamType:(int)streamType realpalyState:(REALPLAY_STATE *)state
{
    g_logic.get_realplay_state(did, channel, streamType, state);
}

-(int)switchDecoder:(int)playType did:(int)did channel:(int)channel streamType:(int)streamType decoder:(BOOL)decoder
{
    return g_logic.switch_decoder(playType, did, channel, streamType, decoder);
}

-(int)getRealplayFlux:(int)did channel:(int)channel streamType:(int)streamType
{
    return g_logic.get_realplay_flux(did, channel, streamType);
}

-(void)forceIframe:(int)did channel:(int)channel streamType:(int)streamType
{
    g_logic.force_iframe(did, channel, streamType);
}

-(void)searchDevice
{
    g_logic.search_device();
}

-(int)startTalk:(int)did
{
    return g_logic.start_talk(did);
}

-(void)stopTalk:(int)did
{
    g_logic.stop_talk(did);
}

-(void)sendTalkData:(int)did data:(const void *)data length:(unsigned int)len
{
    g_logic.send_talk_data(did, data, len);
}

-(int)startMultiPreview:(int)did decoder:(BOOL)decoder
{
    return g_logic.start_multi_preview(did, decoder);
}

-(void)stopMultiPreview:(int)did
{
    g_logic.stop_multi_preview(did);
}

-(void)switchMultiPreview:(int)did channels:(unsigned int)channels
{
    g_logic.switch_multi_preview(did, channels);
}
-(int) get_control_ability:(int)did enable:(unsigned int *)enable
{
    return g_logic.get_control_ability(did, *enable);
}
-(int) control_mouse_click:(int)did button_type:(int)button_type cx:(int)cx cy:(int)cy
{
    return g_logic.control_mouse_click(did, button_type, cx, cy);
}
-(int) control_text_input:(int)did  textString:(const char *)text
{
    return g_logic.control_text_input(did, text);
}

-(void)ptzControl:(int)did channel:(int)channel type:(int)type step:(int)step start:(BOOL)start
{
    g_logic.ptz_control(did, channel, type, step, start);
}

-(void)ptzSetPreset:(int)did channel:(int)channel point:(int)point
{
    g_logic.ptz_set_preset(did, channel, point);
}

-(void)ptzCallPreset:(int)did channel:(int)channel point:(int)point
{
    g_logic.ptz_call_preset(did, channel, point);
}

-(void)ptzCtrlCruise:(int)did channel:(int)channel value:(int)value start:(BOOL)start
{
    g_logic.ptz_ctrl_cruise(did, channel, value, start);
}

-(void)ptzCtrlPattern:(int)did channel:(int)channel value:(int)value start:(BOOL)start
{
    g_logic.ptz_ctrl_pattern(did, channel, value, start);
}

-(void)ptzCtrlCamera:(int)did channel:(int)channel type:(int)type
{
    g_logic.ptz_ctrl_camera(did, channel, type);
}

-(void)keyboardControl:(int)did button:(int)btn
{
    g_logic.keyboard_control(did, btn);
}

-(void)queryRecord:(int)did channel:(int)channel streamType:(int)streamType start:(const LOGIC_TIME *)start end:(const LOGIC_TIME *)end qrParam:(int)qrParam
{
    g_logic.query_record(did, channel, streamType, start, end, qrParam);
}

-(void)stopQueryRecord:(int)did channel:(int)channel streamType:(int)streamType qrParam:(int)qrParam
{
    g_logic.stop_query_record(did, channel, streamType, qrParam);
}

-(int)startPlayback:(int)did channel:(int)channel streamType:(int)streamType start:(const LOGIC_TIME *)start end:(const LOGIC_TIME *)end records:(NSMutableArray *)records num:(unsigned int)num decoder:(bool)decoder
{
    LOGIC_RECORD_INFO *record_info = (LOGIC_RECORD_INFO *)malloc(sizeof(LOGIC_RECORD_INFO)*records.count);

    for (int i = 0; i < records.count; i++) {
        
        [[records objectAtIndex:i] getBytes:&record_info[i] length:sizeof(LOGIC_RECORD_INFO)];
        
    }
    
    int nRet = g_logic.start_playback(did, channel, streamType, start, end, record_info, num, decoder);
    
    if (record_info) {
        free(record_info),record_info = NULL;
    }
    
    return nRet;
}

-(void)stopPlayback:(int)did channel:(int)channel streamType:(int)streamType
{
    g_logic.stop_playback(did, channel, streamType);
}

-(void)controlPlayback:(int)did channel:(int)channel streamType:(int)streamType ctrl:(int)ctrl
{
    g_logic.control_playback(did, channel, streamType, ctrl);
}

-(void)seekPlayback:(int)did channel:(int)channel streamType:(int)streamType time:(const LOGIC_TIME *)time
{
    g_logic.seek_playback(did, channel, streamType, time);
}

-(int)getMonthRecord:(int)did channel:(int)channel year:(int)year month:(int)month record:(unsigned int *)record
{
    return g_logic.get_month_record(did, channel, year, month, *record);
}

-(void)yuv2rgb32:(const void *)y u:(const void *)u v:(const void *)v width:(unsigned int)width height:(unsigned int)height rgb32:(void *)rgb32
{
    g_logic.yuv2rgb32(y, u, v, width, height, rgb32);
}

-(void)yuv2rgb24:(const void *)y u:(const void *)u v:(const void *)v width:(unsigned int)width height:(unsigned int)height rgb24:(void *)rgb24
{
    g_logic.yuv2rgb24(y, u, v, width, height, rgb24);
}

-(void)yuv2rgb565:(const void *)y u:(const void *)u v:(const void *)v width:(unsigned int)width height:(unsigned int)height rgb24:(void *)rgb565
{
    g_logic.yuv2rgb565(y, u, v, width, height, rgb565);
}

-(void) yuv2rgb:(const void *)y u:(const void *)u v:(const void*)v width:(unsigned int)width height:(unsigned int)height rgb:(void *)rgb fmt:(int)fmt
{
    g_logic.yuv2rgb(y, u, v, width, height, rgb, fmt);
}

-(void) rgb2yuv:(const void *)rgb fmt:(int)fmt width:(unsigned int)width height:(unsigned int)height yuv:(void *)yuv
{
    g_logic.rgb2yuv(rgb, fmt, width, height, yuv);
}

-(int)getAlarmOutCount:(int)did count:(unsigned int *)count
{
    return g_logic.get_alarm_out_count(did, count);
}

-(int)getAlarmOut:(int)did state:(unsigned int *)state
{
    return g_logic.get_alarm_out(did, state);
}

-(int)setAlarmOut:(int)did state:(unsigned int)state
{
    return g_logic.set_alarm_out(did, state);
}

-(const char *)getP2PVersion
{
    return g_logic.get_p2p_version();
}
- (int)supportStream3Did:(int)did channel:(int)channel streamtypes:(int)streamtypes stream3:(unsigned int *)stream3
{
    return g_logic.support_stream(did, channel, streamtypes, *stream3);
}

-(int)setDeviceTime:(int)did time:(LOGIC_TIME *)time
{
    return g_logic.set_device_time(did, time);
}
- (int)get_sensor_list:(int)did val:(LOGIC_STRING *)val
{
    return g_logic.get_sensor_list(did, val);
}
- (int)get_sensor_point:(int)did sensorID:(int)sensorID count:(int)count value:(LOGIC_STRING *)value
{
    return g_logic.get_sensor_point(did, sensorID, count, value);
}

- (int)get_point_value_by_ID:(int)did sensorID:(int)sensorID pointIDs:(NSMutableArray *)pointIDs point_count:(int)point_count value:(LOGIC_STRING *)value
{
    LOGIC_POINTID *pointID = (LOGIC_POINTID *)malloc(sizeof(LOGIC_POINTID)*point_count);
    
    for (int i = 0; i < pointIDs.count; i++) {
        
        [[pointIDs objectAtIndex:i] getBytes:&pointID[i] length:sizeof(LOGIC_POINTID)];
        
    }
    
    int nRet = g_logic.get_point_value_by_ID(did, sensorID, pointID, point_count,value);
    
    if (pointID) {
        free(pointID),pointID = NULL;
    }
    
    return nRet;
   
}
- (int)get_point_struct_by_id:(int)did param:(POINT_STRUCT_BY_ID *)param value:(LOGIC_STRING *)value
{
    return g_logic.get_point_struct_by_id(did, param, value);
}

- (int)get_point_value_by_ID1:(int)did sensorID:(int)sensorID pointIDs:(LOGIC_POINTID *)pointIDs point_count:(int)point_count value:(LOGIC_STRING *)value
{
    return g_logic.get_point_value_by_ID(did, sensorID, pointIDs, point_count,value);
}
-(int)get_point_value_by_index:(int)did sensorID:(int)sensorID indexType:(int)indexType range:(int *)range rangCount:(int)rangCount value:(LOGIC_STRING *)value
{
    return g_logic.get_point_value_by_index(did, sensorID, indexType, range, rangCount, value);
}

-(int)get_sensor_state:(int)did sensorID:(int)sensorID value:(LOGIC_STRING *)value
{
    return g_logic.get_sensor_state(did, sensorID, value);
}

-(int)set_point_value:(int)did sensorID:(int)sensorID pointID:(const char *)pointID value:(double)value
{
    return g_logic.set_point_value(did, sensorID, pointID, value);
}
- (int)set_point_value_string:(int)did sensorID:(int)sensorID pointID:(const char *)pointID value:(const char *)value
{
    return g_logic.set_point_value_string(did, sensorID, pointID, value);
}
-(int)get_history_point_data:(int)did parm:(POINT_DATA_PAM *)param value:(LOGIC_STRING *)value
{
    return g_logic.get_history_point_data(did, param, value);
}

-(void)release_string:(LOGIC_STRING *)val
{
    g_logic.release_string(val);
}
- (int)get_sensor_point_by_range:(int)did param:(POINT_DATA_BY_RANGE *)param value:(LOGIC_STRING *)value
{
    return g_logic.get_sensor_point_by_range(did, param, value);
}

-(int)getDevConfig:(int)did type:(const char *)type channel:(int)channel value:(LOGIC_STRING *)value
{
    return g_logic.get_dev_config(did, type, channel, value);
}

-(int)setDevConfig:(int)did config:(const char *)config
{
    return g_logic.set_dev_config(did, config);
}

-(int)getOutSlots:(int)did outCount:(unsigned int *)outCount
{
    return g_logic.get_out_slots(did, outCount);
}

-(int)getConfigCaps:(int)did channel:(int)channel streamType:(const char *)streamType value:(LOGIC_STRING *)value
{
    return g_logic.get_config_caps(did, channel, streamType, value);
}
@end
