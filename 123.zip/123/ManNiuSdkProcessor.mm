//
//  ManNiuSdkProcessor.m
//  manniu
//
//  Created by paperman on 2015/5/21.
//  Copyright © 2017年 ManNiu. All rights reserved.
//

#import "MNSdkCType.h"
#import "AppDataCenter.h"
#import "ManNiuSdkProcessor.h"

@interface ManNiuSdkProcessor(){
    NSMutableArray *mObservers;
    dispatch_queue_t mEtsIdmQueue;
}

@end


@implementation ManNiuSdkProcessor

static ManNiuSdkProcessor *g_ManNiuSdkProcessor = nil;

-(instancetype)init{
    self = [super init];
    
    if (self) {
        mObservers = [NSMutableArray new];
    }
    return self;
}

-(void)initialize{
    
    ManNiuSdkSetCallback(onVideoDataRecved, onAudioDataRecved, onEtsTunnelRecved, onTaskStatusRecved, onRequestToBindDevice, onCallOutRecved);
    
//    ManNiuSdkSetCallback(onVideoDataRecved, onAudioDataRecved, onCommandRecved, onP2PStatusRecved, onEtsTunnelRecved, onTunnelRecved, onTaskStatusRecved, onRequestToBindDevice);
}

-(void)initManNiuSdk{
    return ManNiuSdkInit();
}

-(void)uninitManNiuSdk{
    return ManNiuSdkUnInit();
}

+(instancetype)sharedInstance{
    @synchronized (self) {
        if (g_ManNiuSdkProcessor == nil){
            g_ManNiuSdkProcessor = [[ManNiuSdkProcessor alloc] init];
        }
        return g_ManNiuSdkProcessor;
    }
}

+(instancetype)allocWithZone:(struct _NSZone *)zone{
    @synchronized(self){
        if (g_ManNiuSdkProcessor == nil) {
            
            g_ManNiuSdkProcessor = [super allocWithZone:zone];
            
            return g_ManNiuSdkProcessor; // assignment and return on first
        }
    }
    
    return nil;
}

-(void)addObserver:(id<ManNiuSdkDelegate>)observer{
    if (!observer) return ;
    
    @synchronized (mObservers) {
        for (NSValue *value in mObservers){
            if ([value nonretainedObjectValue] == observer)
                return ;
        }
        
        NSValue *val = [NSValue valueWithNonretainedObject:observer];
        [mObservers addObject:val];
    }
}

-(void)removeObserver:(id<ManNiuSdkDelegate>)observer{
    @synchronized (mObservers) {
        [mObservers enumerateObjectsUsingBlock:^(NSValue *val, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([val nonretainedObjectValue] == observer){
                [mObservers removeObject:val];
                
                *stop = YES;
            }
        }];
    }
}

#pragma mark ManNiuSdkDelegate
-(void)didManNiuSdk_P2pStatusRecved:(long)lTaskContext type:(int)nType status:(int)nStatus destUUID:(char *)pDestUUID userdata:(void *)userdata{
    @synchronized (mObservers) {
        for (NSValue *val in mObservers){
            id<ManNiuSdkDelegate>obj = [val nonretainedObjectValue];
            
            if ([obj respondsToSelector:@selector(didManNiuSdk_P2pStatusRecved:type:status:destUUID:userdata:)]){
                
                [obj didManNiuSdk_P2pStatusRecved:lTaskContext type:nType status:nStatus destUUID:pDestUUID userdata:userdata];
            }
        }
    }
}

-(void)didManNiuSdk_CommandRecved:(long)lTaskContext channelId:(int)nChannelId cmd:(int)nCmd value:(int)nValue jsonData:(char *)pszJsonData length:(int)nLength{
     @synchronized (mObservers) {
         for (NSValue *val in mObservers){
             id<ManNiuSdkDelegate>obj = [val nonretainedObjectValue];
             
             if ([obj respondsToSelector:@selector(didManNiuSdk_CommandRecved:channelId:cmd:value:jsonData:length:)]){
                 
                 [obj didManNiuSdk_CommandRecved:lTaskContext channelId:nChannelId cmd:nCmd value:nValue jsonData:pszJsonData length:nLength];
             }
         }
     }
}

/**
 Description        : 解码前的原始数据回调(H.264/H.265)
 
 @param lSessionId	: session id
 @param nChannelId  : 设备通道号
 @param pInData     : 数据(H.264/H.265)
 @param nDataLen    : 数据长度
 @param nWidth      : 图片宽
 @param nHeight     : 图片高
 @param nFps        : 帧率
 @param nEncodeType : 编码类型(H.264/H.265)
 @param nSliceType  : 分片类型(I/B/P)
 @param nYear       : 当前一帧显示年
 @param nMonth      : 当前一帧显示月
 @param nDay        : 当前一帧显示日
 @param nHour       : 当前一帧显示小时
 @param nMinute     : 当前一帧显示分
 @param nSecond     : 当前一帧显示秒
 @param nTimestamp  : 当前一帧显示时间戳
 */
-(void)didManNiuSdk_VideoDataRecved:(long)lTaskContext channelId:(int)nChannelId userdata:(void *)userdata type:(MN_OUTPUT_DATA_TYPE)type data:(void *)pData length:(int)nLength y:(const unsigned char *)pY u:(const unsigned char *)pU v:(const unsigned char *)pV width:(int)nWidth height:(int)nHeight ystride:(int)nYStride ustride:(int)nUStride vstride:(int)nVStride fps:(int)nFps bitRate:(float)fBitRate sliceType:(int)nSliceType year:(int)nYear month:(int)nMonth day:(int)nDay hour:(int)nHour minute:(int)nMinute second:(int)nSecond networkTraffic:(double)fNetworkTraffic{
    
    @synchronized (mObservers) {
        for (NSValue *val in mObservers){
            id<ManNiuSdkDelegate>obj = [val nonretainedObjectValue];
            
            if ([obj respondsToSelector:@selector(didManNiuSdk_VideoDataRecved:channelId:userdata:type:data:length:y:u:v:width:height:ystride:ustride:vstride:fps:bitRate:sliceType:year:month:day:hour:minute:second:networkTraffic:)]){
                
                [obj didManNiuSdk_VideoDataRecved:lTaskContext channelId:nChannelId userdata:userdata type:type data:pData length:nLength y:pY u:pU v:pV width:nWidth height:nHeight ystride:nYStride ustride:nUStride vstride:nVStride fps:nFps bitRate:fBitRate sliceType:nSliceType year:nYear month:nMonth day:nDay hour:nHour minute:nMinute second:nSecond networkTraffic:fNetworkTraffic];
            }
        }
    }
}

-(void)didManNiuSdk_AudioDataRecved:(long)lTaskContext channelId:(int)nChannelId userdata:(void *)userdata data:(unsigned char *)pData length:(int)nLength encodeType:(int)nEncodeType{

    @synchronized (mObservers) {
        for (NSValue *val in mObservers){
            id<ManNiuSdkDelegate>obj = [val nonretainedObjectValue];
            
            if ([obj respondsToSelector:@selector(didManNiuSdk_AudioDataRecved:channelId:userdata:data:length:encodeType:)]){
                
                [obj didManNiuSdk_AudioDataRecved:lTaskContext channelId:nChannelId userdata:userdata data:pData length:nLength encodeType:nEncodeType];
            }
        }
    }
}

-(void)didManNiuSdk_EtsTunnelRecved:(const char *)uuid data:(const char *)pJsonData length:(unsigned int)nLen{
    @synchronized (mObservers) {
        for (NSValue *val in mObservers){
            id<ManNiuSdkDelegate>obj = [val nonretainedObjectValue];
            
            if ([obj respondsToSelector:@selector(didManNiuSdk_EtsTunnelRecved:data:length:)]){
                
                [obj didManNiuSdk_EtsTunnelRecved:uuid data:pJsonData length:nLen];
            }
        }
    }
}

-(void)didManNiuSdk_TunnelCommandRecved:(const char *)pDevUuid data:(const char *)pData length:(unsigned int)uLen{
    @synchronized (mObservers) {
        for (NSValue *val in mObservers){
            id<ManNiuSdkDelegate>obj = [val nonretainedObjectValue];
            
            if ([obj respondsToSelector:@selector(didManNiuSdk_TunnelCommandRecved:data:length:)]){
                
                [obj didManNiuSdk_TunnelCommandRecved:pDevUuid data:pData length:uLen];
            }
        }
    }
}

-(void)didManNiuSdk_PlayBackStatusRecved:(long)lTaskContext userdata:(void *)userdata status:(int)nPlayStatus{
    @synchronized (mObservers) {
        for (NSValue *val in mObservers){
            id<ManNiuSdkDelegate>obj = [val nonretainedObjectValue];
            
            if ([obj respondsToSelector:@selector(didManNiuSdk_PlayBackStatusRecved:userdata:status:)]){
                
                [obj didManNiuSdk_PlayBackStatusRecved:lTaskContext userdata:userdata status:nPlayStatus];
            }
        }
    }
}

-(void)didManNiuSdk_TaskStatusRecved:(long)lTaskContext userdata:(void *)userdata status:(int)nPlayStatus progress:(float)fProgress{
    @synchronized (mObservers) {
        for (NSValue *val in mObservers){
            id<ManNiuSdkDelegate>obj = [val nonretainedObjectValue];
            
            if ([obj respondsToSelector:@selector(didManNiuSdk_TaskStatusRecved:userdata:status:progress:)]){
                
                [obj didManNiuSdk_TaskStatusRecved:lTaskContext userdata:userdata status:nPlayStatus progress:fProgress];
            }
        }
    }
}

-(void)didManNiuSdk_RequestToBindDeviceRecved:(const char *)pszJson length:(unsigned int)uLen{
    @synchronized (mObservers) {
        for (NSValue *val in mObservers){
            id<ManNiuSdkDelegate>obj = [val nonretainedObjectValue];
            
            if ([obj respondsToSelector:@selector(didManNiuSdk_RequestToBindDeviceRecved:length:)]){
                
                [obj didManNiuSdk_RequestToBindDeviceRecved:pszJson length:uLen];
            }
        }
    }
}

-(void)didManNiuSdk_CallOutRecved:(const char *)pJsonData length:(unsigned int)uLen{
    @synchronized (mObservers) {
        for (NSValue *val in mObservers){
            id<ManNiuSdkDelegate>obj = [val nonretainedObjectValue];

            if ([obj respondsToSelector:@selector(didManNiuSdk_CallOutRecved:length:)]){

                [obj didManNiuSdk_CallOutRecved:pJsonData length:uLen];
            }
        }
    }
}

@end
