//
//  ManNiuSDKCallBack.m
//  manniu
//
//  Created by PaperMan on 15/6/29.
//  Copyright (c) 2015年 manniu. All rights reserved.
//

#import "DataDef.h"
#import "MNPublic.h"
#import "AppDataCenter.h"
#import "ManNiuSdkCallBack.h"
#import "ManNiuSdkProcessor.h"

void onVideoDataRecved(long lTaskContext, long nChannelId, void *userdata, MN_OUTPUT_DATA_TYPE type, void *data, int nDataLen, const unsigned char *pY, const unsigned char *pU, const unsigned char *pV, int nWidth, int nHeight, int nYStride, int nUStride, int nVStride, int nFps, int nSliceType, int nYear, int nMonth, int nDay, int nHour, int nMinute, int nSecond, double fNetworkTraffic){

    [[ManNiuSdkProcessor sharedInstance] didManNiuSdk_VideoDataRecved:lTaskContext channelId:(int)nChannelId userdata:userdata type:type data:data length:nDataLen y:pY u:pU v:pV width:nWidth height:nHeight ystride:nYStride ustride:nUStride vstride:nVStride fps:nFps bitRate:0.0 sliceType:nSliceType year:nYear month:nMonth day:nDay hour:nHour minute:nMinute second:nSecond networkTraffic:fNetworkTraffic];
}

void onAudioDataRecved(long lTaskContext, int nChannelId, void *userdata, unsigned char *pInData, int nDataLen, int nEncodeType){
    [[ManNiuSdkProcessor sharedInstance] didManNiuSdk_AudioDataRecved:lTaskContext channelId:nChannelId userdata:userdata data:pInData length:nDataLen encodeType:nEncodeType];
}

void onCommandRecved(long lTaskContext, int nChannelID, int nCmd, int nValue, char *pszJsonData, int nLen){
    [[ManNiuSdkProcessor sharedInstance] didManNiuSdk_CommandRecved:lTaskContext channelId:nChannelID cmd:nCmd value:nValue jsonData:pszJsonData length:nLen];
}

void onEtsTunnelRecved(const char *pDestSID, const char *pJsonData, unsigned int uLen){
    [[ManNiuSdkProcessor sharedInstance] didManNiuSdk_EtsTunnelRecved:pDestSID data:pJsonData length:uLen];
}

void onP2PStatusRecved(long lTaskContext, int nType, int nStatus, char *pDestSID, void *userdata){
    [[ManNiuSdkProcessor sharedInstance] didManNiuSdk_P2pStatusRecved:lTaskContext type:nType status:nStatus destUUID:pDestSID userdata:userdata];
}

void onTunnelRecved(const char *pDevSID, const char *pData, unsigned int uLen){
    [[ManNiuSdkProcessor sharedInstance] didManNiuSdk_TunnelCommandRecved:pDevSID data:pData length:uLen];
}

void onPlayBackStatusRecved(long lTaskContext, void *userdata, int nPlayStatus){
    [[ManNiuSdkProcessor sharedInstance] didManNiuSdk_PlayBackStatusRecved:lTaskContext userdata:userdata status:nPlayStatus];
}

void onTaskStatusRecved(long lTaskContext, void *userdata, MNTASK_STATUS_CODE_t nPlayStatus, float fProgress){
    [[ManNiuSdkProcessor sharedInstance] didManNiuSdk_TaskStatusRecved:lTaskContext userdata:userdata status:nPlayStatus progress:fProgress];
}

void onRequestToBindDevice(const char *pszJson, unsigned int uLen){
    [[ManNiuSdkProcessor sharedInstance] didManNiuSdk_RequestToBindDeviceRecved:pszJson length:uLen];
}

void onCallOutRecved(const char *pJsonData, unsigned int uLen){
    [[ManNiuSdkProcessor sharedInstance] didManNiuSdk_CallOutRecved:pJsonData length:uLen];
}
