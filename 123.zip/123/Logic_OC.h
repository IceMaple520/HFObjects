
#import <Foundation/Foundation.h>
#import "LogicMacro.h"

@protocol LogicListener <NSObject>
/// 回调服务器状态
-(void) onServerStateChange:(const SERVER_STATE*)state;
/// 回调设备状态。如果断线，内部会重连。只要状态变化，都会回调。
-(void) onDeviceStateChange:(int)did state:(const DEVICE_STATE*)state;

@end

@protocol LogicRealPlayListener <NSObject>
/// 实时预览状态回调。即使第一次回调失败，底层也会再次重试。可能还会回调成功。
/// 在打开成功的情况下，如果出现网络错误设备掉线，可能还会回调失败，底层还会进行重试。
-(void) onRealPlayStateChange:(int)did channel:(int)channel streamType:(int)streamType state:(const REALPLAY_STATE*)state;

-(void) onRealPlayVideo:(int)did channel:(int)channel steamType:(int)streamType vframe:(VFRAME_INFO*)vframe deta:(const void*)data length:(unsigned int)len;
-(void) onRealPlayDecoderYUV:(int)did channel:(int)channel streamType:(int)streamType vframe:(VFRAME_INFO*)vframe y:(const void*)y u:(const void*)u v:(const void*)v;

///返回的音频数据已经被解码成PCM编码了。
-(void) onRealPlayAudio:(int)did channel:(int)channel streamType:(int)streamType aframe:(AFRAME_INFO*)aframe data:(const void*) data length:(unsigned int)len;
@end

@protocol LogicSearchListener <NSObject>

-(void) onSearchDevice:(const char*)ip port:(int)port;

@end

@protocol LogicTalkListener <NSObject>
/// 回调语音对讲的结果。LOGIC_ERRCODE_REFUSE表示已经有人在对讲；LOGIC_ERRCODE_SUCCESS打开成功
-(void) onTalkResult:(int)did error:(int)error;
///返回的音频数据已经被解码成PCM编码了。
-(void) onTalkAudio:(int)did aframe:(AFRAME_INFO*)aframe data:(const void*)data length:(unsigned int)len;

@end

@protocol LogicMultiPreviewListener <NSObject>

-(void) onMultiPreviewVideo:(int)did vframe:(VFRAME_INFO*)vframe data:(const void*)data length:(unsigned int)len;
-(void) onMultiPreviewDecoderYUV:(int)did vframe:(VFRAME_INFO*)vframe y:(const void*)y u:(const void*)u v:(const void*)v;

@end

@protocol LogicPlayBackListener <NSObject>

/// 返回搜索到的录像，num=0表示搜索结束
-(void) onQueryRecord:(int)did channel:(int)channel streamType:(int)streamType records:(LOGIC_RECORD_INFO*)records num:(int)num qrParam:(int)qrParam;

/// 返回录像数据。len=0表示录像结束
-(void) onPlaybackVideo:(int)did channel:(int)channel streamType:(int)streamType time:(LOGIC_TIME*)time vframe:(VFRAME_INFO* )vframe data:(const void* )data length:(unsigned int)len;
-(void) onPlaybackDecoderYuv:(int)did channel:(int)channel streamType:(int)streamType time:(LOGIC_TIME*)time  vframe:(VFRAME_INFO* )vframe y:(const void*)y u:(const void*)u v:(const void*)v;

///返回的音频数据已经被解码成PCM编码了。
-(void) onPlaybackAudio:(int)did channel:(int)channel streamType:(int)streamType time:(LOGIC_TIME*)time aframe:(AFRAME_INFO* )aframe data:(const void* )data length:(unsigned int)len;

@end

@interface Logic_OC : NSObject
-(void) setLogicListener:(id<LogicListener>) lsner;
-(void) setLogicRealPlayListener:(id<LogicRealPlayListener>) lsner;
-(void) setLogicSearchListener:(id<LogicSearchListener>) lsner;
-(void) setLogicTalkListener:(id<LogicTalkListener>) lsner;
-(void) setLogicMultiPreviewListener:(id<LogicMultiPreviewListener>) lsner;
-(void) setLogicPlayBackListener:(id<LogicPlayBackListener>) lsner;
/* 单例对象初始化  */
+(Logic_OC*) instance;

//初始化。逻辑层使用前，先初始化
-(void) init:(LOGIC_INIT_PARAM*)param;
-(void) getServerState:(SERVER_STATE*)state;

//获取时间的毫秒数
-(long) getTick;

/// 刷新底层的网络连接状态。画面激活的时候用。
///
/// force=false，断线设备马上重连；如果与服务器断开，马上重连；后台切前台、或者打开设备列表刷新设备状态的时候。
/// force=true，所有设备强制断开重连；重新设置P2P服务器地址；挂起到唤醒的时候调用。挂起的话，检测断线也要一小段时间，为了减少这段时间，强制重连。
-(void) refresh:(BOOL)force;

/// 添加设备
/// return 返回设备的did
-(int)  loginDevice:(DEVICE_LOGIN_PARAM*)param;
//删除设备的时候登出设备
-(void) logoutDevice:(int)did;
-(void) getDeviceState:(int)did deviceState:(DEVICE_STATE*)state;
/// 检查设备。用于添加设备前检查
-(void) checkDevice:(DEVICE_LOGIN_PARAM*)param deviceState:(DEVICE_STATE*)state timeout:(unsigned int)timeout;

/// 打开实时视频。异步接口。
/// param decoder 表示是否解码，如果不解码，on_realplay_decoder_yuv不会回调
/// return >=0 参数没问题，开始打开视频
/// return <0  参数错误，可能did不存在，channel、stream_type值错误
-(int) startRealPlay:(int)did channel:(int)channel streamType:(int)streamType decoder:(BOOL)decoder;
-(void) stopRealPlay:(int)did channel:(int)channel streamType:(int)streamType;
-(void) getRealPlayState:(int)did channel:(int)channel streamType:(int)streamType realpalyState:(REALPLAY_STATE*)state;
//切换码流
-(int) switchDecoder:(int)playType did:(int)did channel:(int)channel streamType:(int)streamType decoder:(BOOL)decoder;
/// 获取实时视频的码率
-(int) getRealplayFlux:(int)did channel:(int)channel streamType:(int)streamType;
-(void) forceIframe:(int)did channel:(int)channel streamType:(int)streamType;
/// 搜索设备。通过set_search_listener回调结果
-(void) searchDevice;

/// 开始对讲
/// return >=0 参数没问题，开始打开视频
/// return <0  参数错误，可能did不存在。
-(int)  startTalk:(int)did;
-(void) stopTalk:(int)did;
/// 发送对讲数据，单通道、8K、16BIT
-(void) sendTalkData:(int)did data:(const void*)data length:(unsigned int)len;

/// 打开实时视频。异步接口。
/// param decoder 表示是否解码，如果不解码，on_realplay_decoder_yuv不会回调
/// return >=0 参数没问题，开始打开视频
/// return LOGIC_ERRCODE_NOSUPPORT 不支持
/// return <0  参数错误，可能did不存在。

-(int)  startMultiPreview:(int)did decoder:(BOOL)decoder;
-(void) stopMultiPreview:(int)did;
-(void) switchMultiPreview:(int)did channels:(unsigned int)channels;
-(int) get_control_ability:(int)did enable:(unsigned int *)enable;
-(int) control_mouse_click:(int)did button_type:(int)button_type cx:(int)cx cy:(int)cy;
-(int) control_text_input:(int)did  textString:(const char *)text;

/// 云台控制
/// param type 方向命令字，同原来
/// param step 移动步长1-8，默认5
-(void) ptzControl:(int)did channel:(int)channel type:(int)type step:(int)step start:(BOOL)start;
-(void) ptzSetPreset:(int)did channel:(int)channel point:(int)point;
-(void) ptzCallPreset:(int)did channel:(int)channel point:(int)point;
-(void) ptzCtrlCruise:(int)did channel:(int)channel value:(int)value start:(BOOL)start;
-(void) ptzCtrlPattern:(int)did channel:(int)channel value:(int)value start:(BOOL)start;
/// 控制镜头
/// param type 1 镜头重置 2 自动聚焦
-(void) ptzCtrlCamera:(int)did channel:(int)channel type:(int)type;
/// 键盘
-(void) keyboardControl:(int)did button:(int)btn;

/// 查询录像记录。播放辅码流，就只查辅码流录像。
-(void) queryRecord:(int)did channel:(int)channel streamType:(int)streamType start:(const LOGIC_TIME* )start end:(const LOGIC_TIME* )end qrParam:(int)qrParam;
-(void) stopQueryRecord:(int)did channel:(int)channel streamType:(int)streamType qrParam:(int)qrParam;
/// 开始回放
/// 支持多录像虚拟成单录像播放，中间无缝衔接。如果只是下载decoder=false，control_playback(PLAYBACK_CTRL_VERY_FAST)
/// param records 需要回放的录像记录。现在的应用可以传入一整天的录像记录。
/// return <0 参数错误
/// return =0 成功
-(int) startPlayback:(int)did channel:(int)channel streamType:(int)streamType start:(const LOGIC_TIME* )start end:(const LOGIC_TIME* )end records:(NSMutableArray* )records num:(unsigned int)num decoder:(bool)decoder;
-(void) stopPlayback:(int)did channel:(int)channel streamType:(int)streamType;
/// 录像控制
/// param ctrl 参考PLAYBACK_CTRL_
-(void) controlPlayback:(int)did channel:(int)channel streamType:(int)streamType ctrl:(int)ctrl;
/// 重定位
/// param time 只能定位在start_playback接口的records参数范围，不能大于end。
-(void) seekPlayback:(int)did channel:(int)channel streamType:(int)streamType time:(const LOGIC_TIME*)time;
//查询录像记录日期
-(int) getMonthRecord:(int)did channel:(int)channel year:(int)year month:(int)month record:(unsigned int *)record;

/// YUV转RGB
-(void) yuv2rgb32:(const void *)y u:(const void *)u v:(const void*)v width:(unsigned int)width height:(unsigned int)height rgb32:(void *)rgb32;
-(void) yuv2rgb24:(const void *)y u:(const void *)u v:(const void*)v width:(unsigned int)width height:(unsigned int)height rgb24:(void *)rgb24;
-(void) yuv2rgb565:(const void *)y u:(const void *)u v:(const void*)v width:(unsigned int)width height:(unsigned int)height rgb24:(void *)rgb565;

-(void) yuv2rgb:(const void *)y u:(const void *)u v:(const void*)v width:(unsigned int)width height:(unsigned int)height rgb:(void *)rgb fmt:(int)fmt;
-(void) rgb2yuv:(const void *)rgb fmt:(int)fmt width:(unsigned int)width height:(unsigned int)height yuv:(void *)yuv;

/// 报警输出，每一位表示一个报警输出状态，0表示关，1表示开。都是堵塞接口。
/// 返回0表示成功，其他为错误码
-(int) getAlarmOutCount:(int)did count:(unsigned int*)count;
-(int) getAlarmOut:(int)did state:(unsigned int*)state;
-(int) setAlarmOut:(int)did state:(unsigned int)state;

- (int)supportStream3Did:(int)did channel:(int)channel streamtypes:(int)streamtypes stream3:(unsigned int *)stream3;


/// 获取P2P版本号
-(const char *)getP2PVersion;

//时间同步
-(int) setDeviceTime:(int)did time:(LOGIC_TIME *)time;
//物联网相关接口
- (int)get_sensor_list:(int)did val:(LOGIC_STRING *)val;
- (int)get_sensor_point:(int)did sensorID:(int)sensorID count:(int)count value:(LOGIC_STRING *)value;
- (int)get_point_value_by_ID:(int)did sensorID:(int)sensorID pointIDs:(NSMutableArray *)pointIDs point_count:(int)point_count value:(LOGIC_STRING *)value;
- (int)get_point_value_by_ID1:(int)did sensorID:(int)sensorID pointIDs:(LOGIC_POINTID *)pointIDs point_count:(int)point_count value:(LOGIC_STRING *)value;
-(int)get_point_value_by_index:(int)did sensorID:(int)sensorID indexType:(int)indexType range:(int *)range rangCount:(int)rangCount value:(LOGIC_STRING *)value;
-(int)get_sensor_state:(int)did sensorID:(int)sensorID value:(LOGIC_STRING *)value;
-(int)set_point_value:(int)did sensorID:(int)sensorID pointID:(const char*)pointID value:(double)value;
- (int)set_point_value_string:(int)did sensorID:(int)sensorID pointID:(const char*)pointID value:(const char*)value;
-(int)get_history_point_data:(int)did parm:(POINT_DATA_PAM *)param value:(LOGIC_STRING*)value;
-(void) release_string:(LOGIC_STRING *)val;
- (int)get_sensor_point_by_range:(int)did param:(POINT_DATA_BY_RANGE *)param value:(LOGIC_STRING *)value;
- (int)get_point_struct_by_id:(int)did param:(POINT_STRUCT_BY_ID *)param value:(LOGIC_STRING *)value;
//画质和报警输出设置相关接口
-(int)getDevConfig:(int)did type:(const char *)type channel:(int)channel value:(LOGIC_STRING *)value;
-(int)setDevConfig:(int)did config:(const char *)config;
//获得报警通道数
-(int)getOutSlots:(int)did outCount:(unsigned int*)outCount;
-(int)getConfigCaps:(int)did channel:(int)channel streamType:(const char *)streamType value:(LOGIC_STRING *)value;
@end

