//
//  ManNiuSdkCallBack.h
//  manniu
//
//  Created by PaperMan on 15/6/29.
//  Copyright (c) 2015年 manniu. All rights reserved.
//  Description: 蛮牛SDK的回调函数
//

#ifndef __SDK_CALL_BACK_H__
#define __SDK_CALL_BACK_H__

#include "MNSdkCType.h"

void onVideoDataRecved(long lTaskContext, long nChannelId, void *userdata, MN_OUTPUT_DATA_TYPE type, void *data, int nDataLen, const unsigned char *pY, const unsigned char *pU, const unsigned char *pV, int nWidth, int nHeight, int nYStride, int nUStride, int nVStride, int nFps, int nSliceType, int nYear, int nMonth, int nDay, int nHour, int nMinute, int nSecond, double fNetworkTraffic);

void onAudioDataRecved(long lTaskContext, int nChannelId, void *userdata, unsigned char *pInData, int nDataLen, int nEncodeType);

void onCommandRecved(long lTaskContext, int nChannelID, int nCmd, int nValue, char *pszJsonData, int nLen);

void onEtsTunnelRecved(const char *pDestSID, const char *pJsonData, unsigned int uLen);

void onP2PStatusRecved(long lTaskContext, int nType, int nStatus, char *pDestSID, void *userdata);

void onTunnelRecved(const char *pDevSID, const char *pData, unsigned int uLen);

void onPlayBackStatusRecved(long lTaskContext, void *userdata, int nPlayStatus);

void onTaskStatusRecved(long lTaskContext, void *userdata, MNTASK_STATUS_CODE_t nPlayStatus, float fProgress);

void onRequestToBindDevice(const char *pszJson, unsigned int uLen);

void onCallOutRecved(const char *pJsonData, unsigned int uLen);

#pragma mark ManNiuSdkDelegate
@protocol ManNiuSdkDelegate <NSObject>

@optional

/**
 Description        :

 @param lSessionId  :
 @param nChannelId  :
 @param pData       :
 @param pY          :
 @param yU          :
 @param pV          :
 @param nWidth      :
 @param nHeight     :
 @param nYStride    :
 @param nUStride    :
 @param nVStride    :
 @param type        :
 @param nYear       :
 @param nMonth      :
 @param nDay        :
 @param nHour       :
 @param nMinute     :
 @param nSecond     :
 */
-(void)didManNiuSdk_VideoDataRecved:(long)lTaskContext channelId:(int)nChannelId userdata:(void *)userdata type:(MN_OUTPUT_DATA_TYPE)type data:(void *)pData length:(int)nLength y:(const unsigned char *)pY u:(const unsigned char *)pU v:(const unsigned char *)pV width:(int)nWidth height:(int)nHeight ystride:(int)nYStride ustride:(int)nUStride vstride:(int)nVStride fps:(int)nFps bitRate:(float)fBitRate sliceType:(int)nSliceType year:(int)nYear month:(int)nMonth day:(int)nDay hour:(int)nHour minute:(int)nMinute second:(int)nSecond networkTraffic:(double)fNetworkTraffic;

/**
 *  Description         : 蛮牛SDK 音频数据回调接口
 *
 *  @param nPcmFlag     :
 *  @param pData        :
 *  @param nLength      :
 */
-(void)didManNiuSdk_AudioDataRecved:(long)lTaskContext channelId:(int)nChannelId userdata:(void *)userdata data:(unsigned char *)pData length:(int)nLength encodeType:(int)nEncodeType;

/**
 *  Description         : 蛮牛SDK 命令回调接口
 *
 *  @param nCmd         : 命令字
 *  @param nSessionID   : sessionId
 *  @param nChannelID   : 通道号[0..n]
 *  @param nFrameRate   : 帧率
 *  @param nBitRate     : 比特率
 *  @param nWidth       : 宽
 *  @param nHeight      : 高
 *  @param nParam       : ...
 *  @param pszData1     : ...
 *  @param pszData2     : ...
 *  @param pszData3     : ...
 */
-(void)didManNiuSdk_CommandRecved:(long)lTaskContext channelId:(int)nChannelId cmd:(int)nCmd value:(int)nValue jsonData:(char *)pszJsonData length:(int)nLength;

/**
 *  Description         :
 *
 *  @param lContext     :
 *  @param uuid         :
 *  @param pData        :
 *  @param nLen         :
 */
-(void)didManNiuSdk_EtsTunnelRecved:(const char *)uuid data:(const char *)pJsonData length:(unsigned int)nLen;

/**
 *  Description         : 蛮牛SDK P2P状态回调接口
 *
 *  @param nValue       :
 *  @param nSessionID   :
 *  @param nStatus      :
 *  @param pDestUUID    :
 *  @param context      :
 *  @param lldDeviceAndChannelId :
 */

-(void)didManNiuSdk_P2pStatusRecved:(long)lTaskContext type:(int)nType status:(int)nStatus destUUID:(char *)pDestUUID userdata:(void *)userdata;

/**
 *  Description         :
 *
 *  @param lContext     :
 *  @param pSenderUuid  :
 *  @param pData        :
 *  @param uLen         :
 */
-(void)didManNiuSdk_TunnelCommandRecved:(const char *)pDevUuid data:(const char *)pData length:(unsigned int)uLen;

/**
 *  Description         :
 *
 *  @param lSessionId   :
 *  @param lldUserData  :
 *  @param nCmd         :
 */
-(void)didManNiuSdk_PlayBackStatusRecved:(long)lTaskContext userdata:(void *)userdata status:(int)nPlayStatus;



/**
 Description            :

 @param nPlayStatus     :
 @param nRecordLen      : 当前长度
 */
-(void)didManNiuSdk_TaskStatusRecved:(long)lTaskContext userdata:(void *)userdata status:(int)nPlayStatus progress:(float)fProgress;

-(void)didManNiuSdk_RequestToBindDeviceRecved:(const char *)pszJson length:(unsigned int)uLen;

-(void)didManNiuSdk_CallOutRecved:(const char *)pJsonData length:(unsigned int)uLen;

@end

#endif  // __SDK_CALL_BACK_H__
