//
//  ManNiuSdkProcessor.h
//  manniu
//
//  Created by paperman on 2017/2/21.
//  Copyright © 2017年 ManNiu. All rights reserved.
//  Description: 蛮牛SDK的回调分发管理
//

#import <Foundation/Foundation.h>

#import "ManNiuSdkCallBack.h"

@interface ManNiuSdkProcessor : NSObject<ManNiuSdkDelegate>

-(void)initialize;

+(ManNiuSdkProcessor * __nonnull)sharedInstance;

-(void)addObserver:(__nonnull id<ManNiuSdkDelegate>)observer;

// ⚠️ observer dealloc时必须从 ManNiuSdkProcessor 单例中移除
-(void)removeObserver:(__nonnull id<ManNiuSdkDelegate>)observer;

-(void)initManNiuSdk;

-(void)uninitManNiuSdk;

@end
