//
//  ManNiuSdkProcessor.m
//  manniu
//
//  Created by paperman on 2015/5/21.
//  Copyright © 2017年 ManNiu. All rights reserved.
//

#import "MNSDK.h"
#import "AppDataCenter.h"
#import "ManNiuSdkProcessor.h"

@interface ManNiuSdkProcessor(){
    dispatch_queue_t mEtsIdmQueue;
}

@property (strong, nonatomic) NSPointerArray *mObservers;

@end


@implementation ManNiuSdkProcessor

static ManNiuSdkProcessor *g_ManNiuSdkProcessor = nil;

-(instancetype)init
{
    self = [super init];
    if (self) {
        self.mObservers = [NSPointerArray weakObjectsPointerArray];
    }
    return self;
}

-(void)initialize{
    ManNiu_SDK_Set_Callback(onVideoEncodedDataRecv, onVideoDecodedDataRecv, onAudioData, onCommandRecv, onP2PStatus, onExtCommandRecv, onTunnel, onPlayBackStatus, onCloudAlarmStatus);
}

-(void)initManNiuSdk{
    int nRetCode = ManNiu_SDK_Init();
    NSAssert(0 == nRetCode, @"manniu sdk init failed.");
}

+(instancetype)sharedInstance{
    @synchronized (self) {
        if (g_ManNiuSdkProcessor == nil){
            g_ManNiuSdkProcessor = [[ManNiuSdkProcessor alloc] init];
        }
        return g_ManNiuSdkProcessor;
    }
    
}

+(instancetype)allocWithZone:(struct _NSZone *)zone{
    @synchronized(self){
        if (g_ManNiuSdkProcessor == nil) {
            
            g_ManNiuSdkProcessor = [super allocWithZone:zone];
            
            return g_ManNiuSdkProcessor; // assignment and return on first
        }
    }
    
    return nil;
}

-(void)addObserver:(id<ManNiuSdkDelegate>)observer{
    if (!observer) return ;
    
    @synchronized (self.mObservers) {
        NSArray *observers = [self.mObservers allObjects];
        
        for (id<ManNiuSdkDelegate>value in observers){
            NSLog(@"%@, count = %ld", value, CFGetRetainCount((CFTypeRef) value));
            if (value == observer)
                return ;
        }
        [self.mObservers addPointer:(__bridge void *)observer];
    }
}

-(void)removeObserver:(id<ManNiuSdkDelegate>)observer{
    if (!observer) return ;
    
    @synchronized (self.mObservers) {
        BOOL bRemoved = YES;
        while (bRemoved){
            bRemoved = NO;
            for (int i = 0; i < [self.mObservers count]; i++){
                NSLog(@"%@, %@", [self.mObservers pointerAtIndex:i], observer);
                
                if ([self.mObservers pointerAtIndex:i] == nil || [self.mObservers pointerAtIndex:i] == (__bridge void *)observer){
                    [self.mObservers removePointerAtIndex:i];
                    bRemoved = YES;
                    break;
                }
            }
        }
    }
}


#pragma mark ManNiuSdkDelegate
-(void)didManNiuSdk_P2pStatusRecved:(int)nValue sessionId:(long)nSessionID status:(int)nStatus destUUID:(char *)pDestUUID context:(long)context deviceAndChannelId:(long long)lldDeviceAndChannelId{
    NSLog(@"1111111");
    @synchronized (self.mObservers) {
        NSLog(@"2222222");
        for (id<ManNiuSdkDelegate>obj in self.mObservers){
            NSLog(@"3333333 %@, retain count = %ld", obj, CFGetRetainCount((CFTypeRef)obj ));
            if ([obj respondsToSelector:@selector(didManNiuSdk_P2pStatusRecved:sessionId:status:destUUID:context:deviceAndChannelId:)]){
                [obj didManNiuSdk_P2pStatusRecved:nValue sessionId:nSessionID status:nStatus destUUID:pDestUUID context:context deviceAndChannelId:lldDeviceAndChannelId];
            }
        }
        NSLog(@"44444444");
    }
    NSLog(@"5555555");
}

-(void)didManNiuSdk_CommandRecved:(int)nCmd sessionId:(long)nSessionID channel:(int)nChannelID frameRate:(long)nFrameRate bitRate:(int)nBitRate width:(int)nWidth height:(int)nHeight param:(int)nParam szData1:(char *)pszData1 pszData2:(char *)pszData2 szData3:(char *)pszData3{
     @synchronized (self.mObservers) {
         for (id<ManNiuSdkDelegate>obj in self.mObservers){
             if ([obj respondsToSelector:@selector(didManNiuSdk_CommandRecved:sessionId:channel:frameRate:bitRate:width:height:param:szData1:pszData2:szData3:)]){
                 [obj didManNiuSdk_CommandRecved:nCmd sessionId:nSessionID channel:nChannelID frameRate:nFrameRate bitRate:nBitRate width:nWidth height:nHeight param:nParam szData1:pszData1 pszData2:pszData2 szData3:pszData3];
             }
         }
     }
}

/**
 Description        : 解码前的原始数据回调(H.264/H.265)
 
 @param lSessionId	: session id
 @param nChannelId  : 设备通道号
 @param pInData     : 数据(H.264/H.265)
 @param nDataLen    : 数据长度
 @param nWidth      : 图片宽
 @param nHeight     : 图片高
 @param nFps        : 帧率
 @param nEncodeType : 编码类型(H.264/H.265)
 @param nSliceType  : 分片类型(I/B/P)
 @param nYear       : 当前一帧显示年
 @param nMonth      : 当前一帧显示月
 @param nDay        : 当前一帧显示日
 @param nHour       : 当前一帧显示小时
 @param nMinute     : 当前一帧显示分
 @param nSecond     : 当前一帧显示秒
 @param nTimestamp  : 当前一帧显示时间戳
 */
-(void)didManNiuSdk_VideoEncodedDataRecved:(long)lSessionId channelId:(int)nChannelId data:(unsigned char *)pInData length:(int)nDataLen width:(int)nWidth height:(int)nHeight fps:(int)nFps encodeType:(int)nEncodeType sliceType:(int)nSliceType year:(int)nYear month:(int)nMonth day:(int)nDay hour:(int)nHour minute:(int)nMinute second:(int)nSecond timestamp:(int)nTimestamp{
    
    NSLog(@"??????????");
    
    
//    @synchronized (self.mObservers) {
//        for (id<ManNiuSdkDelegate>obj in self.mObservers){
//            if ([obj respondsToSelector:@selector(didManNiuSdk_VideoEncodedDataRecved:channelId:data:length:width:height:fps:encodeType:sliceType:year:month:day:hour:minute:second:timestamp:)]){
//                
//                [obj didManNiuSdk_VideoEncodedDataRecved:lSessionId channelId:nChannelId data:pInData length:nDataLen width:nWidth height:nHeight fps:nFps encodeType:nEncodeType sliceType:nSliceType year:nYear month:nMonth day:nDay hour:nHour minute:nMinute second:nSecond timestamp:nTimestamp];
//            }
//        }
//    }
}

-(void)didManNiuSdk_AudioDataRecved:(int)nPcmFlag data:(unsigned char *)pData length:(int)nLength sessionId:(long)lSessionId{

//    @synchronized (self.mObservers) {
//        for (id<ManNiuSdkDelegate>obj in self.mObservers){
//            if ([obj respondsToSelector:@selector(didManNiuSdk_AudioDataRecved:data:length:sessionId:)]){
//                [obj didManNiuSdk_AudioDataRecved:nPcmFlag data:pData length:nLength sessionId:lSessionId];
//            }
//        }
//    }
}

-(void)didManNiuSdk_ExtCommandRecved:(long)lContext destUUID:(const char *)uuid data:(const char *)pData length:(unsigned int)nLen{
    @synchronized (self.mObservers) {
        for (id<ManNiuSdkDelegate>obj in self.mObservers){
            if ([obj respondsToSelector:@selector(didManNiuSdk_ExtCommandRecved:destUUID:data:length:)]){
                [obj didManNiuSdk_ExtCommandRecved:lContext destUUID:uuid data:pData length:nLen];
            }
        }
    }
}

-(void)didManNiuSdk_TunnelCommandRecved:(long)lContext uuid:(const char *)pSenderUuid data:(const char *)pData length:(unsigned int)uLen{
    @synchronized (self.mObservers) {
        for (id<ManNiuSdkDelegate>obj in self.mObservers){
            if ([obj respondsToSelector:@selector(didManNiuSdk_TunnelCommandRecved:uuid:data:length:)]){
                [obj didManNiuSdk_TunnelCommandRecved:lContext uuid:pSenderUuid data:pData length:uLen];
            }
        }
    }
}

-(void)didManNiuSdk_PlayBackStatusRecved:(long)lSessionId userdata:(long long)lldUserData cmd:(int)nCmd{
    @synchronized (self.mObservers) {
        for (id<ManNiuSdkDelegate>obj in self.mObservers){
            if ([obj respondsToSelector:@selector(didManNiuSdk_PlayBackStatusRecved:userdata:cmd:)]){
                [obj didManNiuSdk_PlayBackStatusRecved:lSessionId userdata:lldUserData cmd:nCmd];
            }
        }
    }
}

-(void)didManNiuSdk_CloudAlarmStatusRecved:(int)nPlayStatus length:(int)nRecordLen{
    @synchronized (self.mObservers) {
        for (id<ManNiuSdkDelegate>obj in self.mObservers){
            if ([obj respondsToSelector:@selector(didManNiuSdk_CloudAlarmStatusRecved:length:)]){
                [obj didManNiuSdk_CloudAlarmStatusRecved:nPlayStatus length:nRecordLen];
            }
        }
    }
}

@end
